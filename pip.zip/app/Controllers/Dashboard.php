<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $currentYear = date('Y');
        $data = [
            'judul' => 'Dashboard',
            'currentYear' => $currentYear,
        ];
        return view('admin/dashboard', $data);
    }
    public function searchByNisn()
    {
        $nisn = $this->request->getPost('nisn');

        // Pastikan NISN ada sebelum melakukan query
        if (!empty($nisn)) {
            $db = \Config\Database::connect();

            $builder = $db->table('tbl_danapip');
            $builder->select('tbl_danapip.nisn, tbl_danapip.nama_pd, tbl_danapip.jenis_bantuan, tbl_danapip.tanggal_sk, tbl_danapip.tahap_id');
            $builder->where('tbl_danapip.nisn', $nisn);

            $query1 = $builder->get();

            $builder = $db->table('tbl_dana_lainnya');
            $builder->select('tbl_dana_lainnya.nisn, tbl_dana_lainnya.nama_pd, tbl_dana_lainnya.jenis_bantuan, tbl_dana_lainnya.tanggal_sk, tbl_dana_lainnya.tahap_id');
            $builder->where('tbl_dana_lainnya.nisn', $nisn);

            $query2 = $builder->get();

            $result = array_merge($query1->getResultArray(), $query2->getResultArray());
            $data = [
                'judul' => 'Pencarian.....',
                'result' => $result
            ];
            return view('admin/dashboard', $data);
        } else {
            // NISN kosong, tampilkan pesan kesalahan atau redirect ke halaman form
            // Contoh: return redirect()->to(base_url('your_controller'));
        }
    }
}
