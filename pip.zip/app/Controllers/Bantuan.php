<?php

namespace App\Controllers;

use App\Models\PipModel;
use App\Models\MasterDataModel;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;


class Bantuan extends BaseController
{

    protected $pipModel;
    protected $masterdataModel;

    public function __construct()
    {

        $this->pipModel = new PipModel();
        $this->masterdataModel = new MasterDataModel();
    }
    public function index()
    {
        $csrfToken = csrf_hash();
        $selectedYear = $this->request->getVar('selectYear');
        $selectedTahap = $this->request->getVar('selectTahap');
        $selectedDana = $this->request->getVar('selectDana');

        if ($selectedYear === 'Semua' || empty($selectedYear)) {
            $selectedYear = '';
        }

        $pipModel = new PipModel();

        if (empty($selectedTahap) && empty($selectedDana)) {
            // Jika tidak ada filter Tahap dan Dana, ambil semua data
            $siswaPip = $pipModel->getAllSiswaPip();
        } else {
            // Jika ada filter Tahap atau Dana, gunakan metode filter yang sesuai
            $siswaPip = $pipModel->getSiswaPipByYearTahapDana($selectedYear, $selectedTahap, $selectedDana);
        }

        $uniqueYears = $pipModel->getUniqueYearsFromTanggalSK();
        $uniqueTahaps = $pipModel->getUniqueTahapsByYear($selectedYear);
        $uniqueDanas = $pipModel->getUniqueDanas();
        $currentYear = date('Y');
        $data = [
            'judul' => 'Siswa Penerima PIP',
            'siswa_pip' => $siswaPip,
            'uniqueYears' => $uniqueYears,
            'uniqueTahaps' => $uniqueTahaps,
            'uniqueDanas' => $uniqueDanas,
            'selectedYear' => $selectedYear,
            'selectedTahap' => $selectedTahap,
            'selectedDana' => $selectedDana,
            'currentYear' => $currentYear,
            'csrfToken' => $csrfToken  // Sertakan token CSRF dalam data
        ];

        return view('admin/bantuan', $data);
    }


    public function importData()
    {
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
        $request = service('request');

        if ($request->getMethod() === 'post' && $request->getFile('excel_file')->isValid()) {
            $excelFile = $request->getFile('excel_file');

            // Pastikan folder penyimpanan untuk file Excel sudah ada
            $uploadPath = WRITEPATH . 'uploads';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }

            // Pindahkan file yang diunggah ke folder penyimpanan
            $excelFileName = $excelFile->getRandomName();
            $excelFile->move($uploadPath, $excelFileName);

            // Proses file Excel (misalnya menggunakan library PhpSpreadsheet)
            $reader = IOFactory::load($uploadPath . '/' . $excelFileName);
            $worksheet = $reader->getActiveSheet();
            $rows = $worksheet->toArray();

            $pipModel = new \App\Models\PipModel();

            foreach ($rows as $row) {
                // Buat data siswa dari baris Excel
                $peserta_didik_id = $row[0];
                $sekolah_id = $row[1];
                $npsn = $row[2];
                $nomenklatur = $row[3];
                $kelas = $row[4];
                $rombel = $row[5];
                $nama_pd = $row[6];
                $nama_ibu_kandung = $row[7];
                $nama_ayah = $row[8];
                $tanggal_lahir = $row[9];
                $tempat_lahir = $row[10];
                $nisn = $row[11];
                $nik = $row[12];
                $jenis_kelamin = $row[13];
                $nominal = $row[14];
                $no_rekening = $row[15];
                $tahap_id = $row[16];
                $nomor_sk = $row[17];
                $tanggal_sk = $row[18];
                $nama_rekening = $row[19];
                $tanggal_cair = $row[20];
                $status_cair = $row[21];
                $no_KIP = $row[22];
                $no_KKS = $row[23];
                $no_KPS = $row[24];
                $virtual_acc = $row[25];
                $nama_kartu = $row[26];
                $semester_id = $row[27];
                $layak_pip = $row[28];
                $keterangan_pencairan = $row[29];
                $confirmation_text = $row[30];
                $tahap_keterangan = $row[31];


                $data = [
                    'peserta_didik_id' => $row[0],
                    'sekolah_id' => $row[1],
                    'npsn' => $row[2],
                    'nomenklatur' => $row[3],
                    'kelas' => $row[4],
                    'rombel' => $row[5],
                    'nama_pd' => $row[6],
                    'nama_ibu_kandung' => $row[7],
                    'nama_ayah' => $row[8],
                    'tanggal_lahir' => $row[9],
                    'tempat_lahir' => $row[10],
                    'nisn' => $row[11],
                    'nik' => $row[12],
                    'jenis_kelamin' => $row[13],
                    'nominal' => $row[14],
                    'no_rekening' => $row[15],
                    'tahap_id' => $row[16],
                    'nomor_sk' => $row[17],
                    'tanggal_sk' => $row[18],
                    'nama_rekening' => $row[19],
                    'tanggal_cair' => $row[20],
                    'status_cair' => $row[21],
                    'no_KIP' => $row[22],
                    'no_KKS' => $row[23],
                    'no_KPS' => $row[24],
                    'virtual_acc' => $row[25],
                    'nama_kartu' => $row[26],
                    'semester_id' => $row[27],
                    'layak_pip' => $row[28],
                    'keterangan_pencairan' => $row[29],
                    'confirmation_text' => $row[30],
                    'tahap_keterangan' => $row[31],


                    // Lanjutkan dengan kolom lainnya
                ];

                $insertedId = $pipModel->insertPip($data);

                $data = [
                    'peserta_didik_id' => $row[0],
                    'sekolah_id' => $row[1],
                    // ... (kolom lainnya)
                    'confirmation_text' => $row[30],
                    'tahap_keterangan' => $row[31],

                    // Tambahkan kolom 'no_surat' dengan format yang diinginkan
                    'no_surat' => '422.5/' . $row[16] . '/' . $insertedId,
                ];

                $pipModel->updatePip($insertedId, $data); // Update data dengan no_surat yang sesuai
            }


            return $this->response->setJSON(['status' => 'success', 'message' => 'Data berhasil diimpor']);
        }

        return redirect()->to('/siswa')->with('error', 'Terjadi kesalahan dalam pengunggahan data.');
    }
    // Fungsi untuk menghasilkan no_surat sesuai format
    private function generateNoSurat($tahap_id, $nisn)
    {
        // Contoh format no_surat: 422.5/Tahap/Id
        return "422.5/{$tahap_id}/{$nisn}";
    }


    public function hapus($id)
    {
        // Membuat instance model
        $pipModel = new \App\Models\PipModel();

        // Melakukan pengecekan apakah siswa dengan ID tersebut ada dalam database
        $siswaPip = $pipModel->find($id);

        if ($siswaPip) {
            // Jika siswa ditemukan, panggil fungsi deleteSiswa untuk menghapus siswa
            $pipModel->hapus($id);

            // Set pesan flash data untuk sukses
            session()->setFlashData('pesanHapusSiswa', 'Siswa Penerima PIP berhasil dihapus.');
        } else {
            // Jika siswa tidak ditemukan, set pesan flash data untuk kesalahan
            session()->setFlashData('error', 'Siswa penerima PIP tidak ditemukan.');
        }

        // Redirect kembali ke halaman /siswa setelah penghapusan
        return redirect()->to('/bantuan/pip');
        // return redirect()->to(base_url tambahkan itu, agar tidak membuat ada tulisan index.php pada url
    }

    public function ambilbank($data_id)
    {
        // Validasi $data_id dan pastikan itu adalah integer atau sesuai kebutuhan Anda.

        // Panggil model
        $pipModel = new PipModel();

        // Update kolom 'ambil_dibank' menjadi 'Sudah diambil'
        $pipModel->updatePip($data_id, ['ambil_dibank' => 'Sudah diambil']);

        // Response JSON jika perlu
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data berhasil diperbarui']);
    }

    public function cetaksuketpip($id)
    {
        // Inisialisasi model
        $pipModel = new PipModel();
        $siswaPip = $pipModel->getdetail($id); // Mengambil data siswa berdasarkan ID
        $masterdataModel = new MasterDataModel();
        $data_cetak = $masterdataModel->getDataById(1);


        // Periksa apakah siswa ditemukan
        if (!$siswaPip) {
            throw PageNotFoundException::forPageNotFound();
        }

        $data = [
            'judul' => 'Suket',
            'siswaPip' => $siswaPip,
            'data_cetak' => $data_cetak
        ];

        return view('admin/print_suket/suket', $data);
    }

    public function hitungCetak($id)
    {
        // Validasi ID atau lakukan operasi lain yang diperlukan

        // Dapatkan jumlah klik dari POST data
        $jumlahKlik = $this->request->getPost('jumlahKlik');

        // Ambil jumlah klik yang ada di database
        $pipModel = new \App\Models\PipModel(); // Ganti dengan nama model yang sesuai
        $existingData = $pipModel->find($id);

        // Jika ada data, tambahkan jumlah klik yang baru
        if ($existingData) {
            $jumlahKlik += $existingData['jumlah_cetak'];
        }

        // Simpan jumlah klik ke dalam database
        $pipModel->update($id, ['jumlah_cetak' => $jumlahKlik]);

        // Respon sukses atau lainnya jika diperlukan
        return $this->response->setJSON(['status' => 'success']);
    }


    // MEMBUAT FILTER DATA 
    public function filterByYearTahapDana()
    {
        $selectedYear = $this->request->getVar('selectYear');
        $selectedTahap = $this->request->getVar('selectTahap');
        $selectedDana = $this->request->getVar('selectDana');

        if ($selectedYear === 'Semua' || empty($selectedYear)) {
            $selectedYear = '';
        }

        $pipModel = new PipModel();

        if ($selectedYear === 'Semua') {
            $siswaPip = $pipModel->getAllSiswaPip();
        } else {
            $siswaPip = $pipModel->getSiswaPipByYearTahapDana($selectedYear, $selectedTahap, $selectedDana);
        }

        $uniqueYears = $pipModel->getUniqueYearsFromTanggalSK();
        $uniqueTahaps = $pipModel->getUniqueTahapsByYear($selectedYear);
        $uniqueDanas = $pipModel->getUniqueDanas(); // Ganti dengan metode yang sesuai

        $data = [
            'judul' => 'Siswa Penerima PIP',
            'siswa_pip' => $siswaPip,
            'uniqueYears' => $uniqueYears,
            'uniqueTahaps' => $uniqueTahaps,
            'uniqueDanas' => $uniqueDanas,
            'selectedYear' => $selectedYear,
            'selectedTahap' => $selectedTahap,
            'selectedDana' => $selectedDana,
        ];

        return view('admin/bantuan', $data);
    }

    public function getTahapsByYear($selectedYear)
    {
        // Pastikan $selectedYear tidak kosong
        if (empty($selectedYear)) {
            return $this->response->setStatusCode(400)->setJSON(['error' => 'Invalid selected year']);
        }

        // Instansiasi model PipModel
        $pipModel = new PipModel();

        // Panggil metode untuk mendapatkan opsi tahap_id berdasarkan tahun
        $tahaps = $pipModel->getUniqueTahapsByYear($selectedYear);

        // Kembalikan data dalam format JSON
        return $this->response->setJSON($tahaps);
    }
}
