<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;
use App\Models\MasterDataModel;

class Akun extends Controller
{
    protected $userModel;
    protected $masterdataModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->masterdataModel = new MasterDataModel();
    }

    public function index()
    {
        session();
        $csrfToken = csrf_hash();
        $masterdataModel = new MasterDataModel();

        $dataCetak = $masterdataModel->getDataById(1);

        $pengguna = $this->userModel->getUser();
        $currentYear = date('Y');
        $data = [
            'judul' => 'Setting Data',
            'set_pengguna' => $pengguna,
            'currentYear' => $currentYear,
            'dataCetak' => $dataCetak,
            'csrfToken' => $csrfToken  // Sertakan token CSRF dalam data
        ];

        return view('admin/setting-sp', $data);
    }

    public function update()
    {

        // Mengambil data yang dikirimkan melalui POST
        $id = $this->request->getPost('id');
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $nama = $this->request->getPost('nama');

        // Validasi data jika diperlukan

        // Lakukan pembaruan data ke database menggunakan model AkunModel
        $userModel = new \App\Models\UserModel();
        $data = [
            'username' => $username,
            'password' => $password,
            'nama' => $nama,

        ];
        $userModel->updateUser($id, $data);

        // Pesan respons
        $response = [
            'status' => 'success', // Atau 'error' jika terjadi kesalahan
            'message' => 'Data berhasil diperbarui', // Pesan sukses atau kesalahan
        ];

        // Kirim respons JSON ke JavaScript
        return $this->response->setJSON($response);
    }

    public function updateData()
    {

        $data = json_decode($this->request->getBody(), true); // Ambil data dari permintaan POST

        $id = 1; // Ganti dengan ID data yang ingin Anda perbarui

        // Panggil model untuk memperbarui data
        $this->masterdataModel->updateData($id, $data);


        // Berikan respons jika diperlukan
        return $this->response->setJSON(['message' => 'Data berhasil diperbaharui']);
    }
}
