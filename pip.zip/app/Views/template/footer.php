</div>
<footer class="main-footer">
    <strong>Copyright &copy; 2023-<?= $currentYear; ?> <a href="https://www.sdnkedungrejo.sch.id">SDN Kedungrejo</a>.</strong> dibuat dengan <i class='fas fa-heart' style='font-size:13px;color:red'></i> by jimbling
</footer>







<script src="../../assets/plugins/jquery/jquery.min.js"></script>
<script src="../../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../assets/plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../assets/plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="../../assets/dist/js/adminlte.min.js?v=3.2.0"></script>
<script src="../../assets/dist/sweet/sweetalert2.all.min.js"></script>
<script src="../../assets/dist/js/alert.js"></script>
<script src="../../assets/dist/sweet/myscript.js"></script>
<script src="../../assets/plugins/select2/js/select2.full.min.js"></script>
<script src="../../assets/plugins/moment/moment.min.js"></script>
<script src="../../assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script>
    $(function() {
        if (window.location.pathname === '/bantuan/pip') {
            $('#BantuanPipTable').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": false,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        }
        if (window.location.pathname === '/bantuan/lainnya') {
            $('#DanaLainTable').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "ordering": false,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        }

    });
</script>
<script>
    $(function() {
        //Date picker
        $('#tanggalSk').datetimepicker({
            format: 'L'
        });
        $('#tanggalLahir').datetimepicker({
            format: 'L'
        });
        $('#tanggalLahir_edit').datetimepicker({
            format: 'L'
        });
        $('#tanggalSk_edit').datetimepicker({
            format: 'L'
        });

    })
</script>
<script>
    $(document).ready(function() {
        // Tangkap klik pada ikon power-off
        $('.nav-items').click(function(e) {
            e.preventDefault(); // Menghentikan tindakan default link

            // Tampilkan SweetAlert konfirmasi
            Swal.fire({
                title: 'Konfirmasi',
                text: 'Apakah Anda yakin ingin keluar?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya'
            }).then((result) => {
                // Jika pengguna menekan tombol 'Ya', arahkan ke link keluar
                if (result.isConfirmed) {
                    window.location.href = '/masuk/keluar';
                }
            });
        });
    });
</script>




</body>

</html>