<?php echo view('template/header.php'); ?>
<div class="content-wrapper">
    <div class="content-header">
    </div>

    <div class="container-fluid">


        <div class="row">
            <section class="col-lg-7 connectedSortable">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">Pencarian dengan NISN</h3>
                    </div>
                    <div class="card-footer">
                        <form action="<?= base_url('search'); ?>" method="post">
                            <div class="input-group">
                                <input type="text" name="nisn" id="nisn" placeholder="Masukkan NISN ..." class="form-control" required>
                                <span class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </span>
                            </div>
                        </form>
                    </div>

                    <div class="card-body">
                        <?php if (!empty($_POST['nisn']) && empty($result)) : ?>
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        icon: 'warning',
                                        title: 'Tidak ditemukan',
                                        text: 'Maaf, peserta didik tidak ditemukan.'
                                    });
                                });
                            </script>
                        <?php endif; ?>
                        <?php if (!empty($result)) : ?>
                            <div class="container-fluid">
                                <?php $i = 1; ?>
                                <?php

                                $prevNISN = null;
                                $prevNama = null;

                                foreach ($result as $row) : ?>
                                    <?php if ($row['nisn'] !== $prevNISN || $row['nama_pd'] !== $prevNama) : ?>
                                        <dl class="row">
                                            <dt class="col-sm-4">NISN</dt>
                                            <dd class="col-sm-8"><?= $row['nisn']; ?></dd>
                                            <dt class="col-sm-4">Nama Peserta Didik</dt>
                                            <dd class="col-sm-8"><?= $row['nama_pd']; ?></dd>
                                        </dl>
                                        <table class="table">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Jenis Bantuan</th>
                                                    <th scope="col">Tanggal SK</th>
                                                    <th scope="col">Tahap</th>
                                                </tr>
                                            </thead>
                                        <?php endif; ?>
                                        <tbody>

                                            <tr>
                                                <th class="text-center" scope="row" style="font-size: 14px;"><?= $i++; ?></th>
                                                <td style="text-align: center; font-size: 14px;"><?= $row['jenis_bantuan']; ?></td>
                                                <td style="text-align: center; font-size: 14px;">
                                                    <?php
                                                    // Tanggal dari format database
                                                    $tanggal_database = $row['tanggal_sk'];

                                                    // Konversi tanggal ke format Indonesia
                                                    $tanggal_indonesia = date("d F Y", strtotime($tanggal_database));

                                                    // Daftar nama bulan dalam bahasa Indonesia
                                                    $bulan_indonesia = [
                                                        'January' => 'Januari',
                                                        'February' => 'Februari',
                                                        'March' => 'Maret',
                                                        'April' => 'April',
                                                        'May' => 'Mei',
                                                        'June' => 'Juni',
                                                        'July' => 'Juli',
                                                        'August' => 'Agustus',
                                                        'September' => 'September',
                                                        'October' => 'Oktober',
                                                        'November' => 'November',
                                                        'December' => 'Desember'
                                                    ];

                                                    // Ganti nama bulan dalam format Indonesia
                                                    $tanggal_indonesia = strtr($tanggal_indonesia, $bulan_indonesia);

                                                    // Tampilkan tanggal dalam format Indonesia
                                                    echo $tanggal_indonesia;
                                                    ?>
                                                </td>
                                                <td style="text-align: center; font-size: 14px;"><?= $row['tahap_id']; ?></td>

                                            </tr>
                                            <?php $prevNISN = $row['nisn'];
                                            $prevNama = $row['nama_pd']; ?>
                                        <?php endforeach; ?>
                                        </tbody>
                                        </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </section>
            <section class="col-lg-5 connectedSortable">
                <p class="text-center">
                    <strong>Progres Pencairan PIP Tahun .....</strong>
                </p>
                <div class="progress-group">
                    Add Products to Cart
                    <span class="float-right"><b>160</b>/200</span>
                    <div class="progress progress-sm">
                        <div class="progress-bar bg-primary" style="width: 80%"></div>
                    </div>
                </div>

                <div class="progress-group">
                    Complete Purchase
                    <span class="float-right"><b>310</b>/400</span>
                    <div class="progress progress-sm">
                        <div class="progress-bar bg-danger" style="width: 75%"></div>
                    </div>
                </div>

            </section>
        </div>

        <div class="progress">
            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    </div>


    <?php echo view('template/footer.php'); ?>