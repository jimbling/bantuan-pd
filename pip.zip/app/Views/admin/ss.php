<?php echo view('template/header.php'); ?>
<div class="content-wrapper">




    <h1>Form Upload</h1>

    <?php if (session()->get('success')) : ?>
        <div><?= session()->get('success') ?></div>
    <?php endif; ?>

    <?= form_open_multipart('/upload/upload') ?>
    <label for="file">Pilih File:</label>
    <input type="file" name="file" id="file" required>
    <br>
    <button type="submit">Upload</button>
    <?= form_close() ?>




    <?php echo view('template/footer.php'); ?>